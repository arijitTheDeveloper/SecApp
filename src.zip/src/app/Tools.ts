export interface Tool{
    name:string;
    description:string;

}